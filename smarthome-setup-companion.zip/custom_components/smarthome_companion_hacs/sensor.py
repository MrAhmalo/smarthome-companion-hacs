import logging
from datetime import timedelta
import homeassistant.util.dt as dt_util

from homeassistant.components.sensor import SensorEntity
from homeassistant.helpers.entity import DeviceInfo

from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)


async def async_setup_entry(hass, entry, async_add_entities):
    sun_manager = hass.data[DOMAIN].get("sun_manager")
    store = hass.data[DOMAIN].get("store")
    blinds_manager = hass.data[DOMAIN].get("blinds_manager")
    if not sun_manager:
        return

    entities = [
        FassadeSunSensor(sun_manager, "nord", "Nord"),
        FassadeSunSensor(sun_manager, "ost", "Ost"),
        FassadeSunSensor(sun_manager, "sued", "Süd"),
        FassadeSunSensor(sun_manager, "west", "West"),
    ]
    if store:
        entities.extend(
            [
                ConfiguredBlindsSensor(hass, store),
                UnconfiguredBlindsSensor(hass, store),
            ]
        )

    async_add_entities(entities)

    # Track dynamically added blind unique IDs
    added_blind_entities = set()

    def add_blind_sensors(event=None):
        if not store or not blinds_manager:
            return
        blinds = store.get_blinds()
        new_entities = []
        for entity_id, config in blinds.items():
            if not entity_id.startswith("cover."):
                continue
            if entity_id not in added_blind_entities:
                new_entities.extend(
                    [
                        BlindOpenTimeSensor(hass, store, blinds_manager, entity_id),
                        BlindCloseTimeSensor(hass, store, blinds_manager, entity_id),
                        BlindSunriseOpenTimeSensor(hass, store, blinds_manager, entity_id),
                        BlindSunsetCloseTimeSensor(hass, store, blinds_manager, entity_id),
                        BlindNextActionSensor(hass, store, blinds_manager, entity_id),
                    ]
                )
                added_blind_entities.add(entity_id)

        if new_entities:
            async_add_entities(new_entities)

    # Initial register
    add_blind_sensors()

    # Dynamic registration upon config reloads/updates
    entry.async_on_unload(
        hass.bus.async_listen(
            "smarthome_companion_blinds_updated", add_blind_sensors
        )
    )


class _BaseBlindsSensor(SensorEntity):
    def __init__(self, hass, store):
        self.hass = hass
        self.store = store

    def _configured_blinds(self):
        blinds = self.store.get_blinds()
        return {
            entity_id: config
            for entity_id, config in blinds.items()
            if entity_id.startswith("cover.")
        }

    def _all_cover_entities(self):
        return {state.entity_id for state in self.hass.states.async_all("cover")}

    def _cover_label(self, entity_id):
        state = self.hass.states.get(entity_id)
        if state and state.attributes.get("friendly_name"):
            name = state.attributes["friendly_name"]
        else:
            name = entity_id.split(".")[-1].replace("_", " ").title()
        return name.replace("Eg", "EG").replace("Og", "OG").replace("Hacs", "HACS")

    async def async_added_to_hass(self):
        self.async_on_remove(
            self.hass.bus.async_listen(
                "smarthome_companion_blinds_updated", self._handle_update
            )
        )

    async def _handle_update(self, event):
        self.async_write_ha_state()


class ConfiguredBlindsSensor(_BaseBlindsSensor):
    def __init__(self, hass, store):
        super().__init__(hass, store)
        self._attr_name = "Smarthome Companion eingerichtete Rollläden"
        self._attr_unique_id = "smarthome_companion_configured_blinds"
        self._attr_icon = "mdi:window-shutter-cog"

    @property
    def device_info(self) -> DeviceInfo:
        return DeviceInfo(
            identifiers={(DOMAIN, "hub")},
            name="SmartHome Companion",
            manufacturer="SmartHome Companion",
            model="Hub & Einstellungen",
        )

    @property
    def native_value(self):
        return len(self._configured_blinds())

    @property
    def extra_state_attributes(self):
        blinds = self._configured_blinds()
        return {
            "configured_count": len(blinds),
            "configured_blinds": [
                {
                    "entity_id": entity_id,
                    "name": self._cover_label(entity_id),
                    "enable_shading": bool(config.get("enable_shading", False)),
                    "window_azimuth": config.get("window_azimuth"),
                    "use_sunrise": bool(config.get("use_sunrise", False)),
                    "use_sunset": bool(config.get("use_sunset", False)),
                }
                for entity_id, config in sorted(blinds.items())
            ],
        }


class UnconfiguredBlindsSensor(_BaseBlindsSensor):
    def __init__(self, hass, store):
        super().__init__(hass, store)
        self._attr_name = "Smarthome Companion nicht eingerichtete Rollläden"
        self._attr_unique_id = "smarthome_companion_unconfigured_blinds"
        self._attr_icon = "mdi:window-shutter-alert"

    @property
    def device_info(self) -> DeviceInfo:
        return DeviceInfo(
            identifiers={(DOMAIN, "hub")},
            name="SmartHome Companion",
            manufacturer="SmartHome Companion",
            model="Hub & Einstellungen",
        )

    @property
    def native_value(self):
        configured = set(self._configured_blinds().keys())
        return len(self._all_cover_entities() - configured)

    @property
    def extra_state_attributes(self):
        configured = set(self._configured_blinds().keys())
        all_covers = sorted(self._all_cover_entities())
        unconfigured = [entity_id for entity_id in all_covers if entity_id not in configured]
        return {
            "unconfigured_count": len(unconfigured),
            "total_cover_entities": len(all_covers),
            "unconfigured_blinds": [
                {
                    "entity_id": entity_id,
                    "name": self._cover_label(entity_id),
                }
                for entity_id in unconfigured
            ],
        }


class FassadeSunSensor(SensorEntity):
    def __init__(self, sun_manager, direction_id, direction_name):
        self.sun_manager = sun_manager
        self._direction_id = direction_id
        self._attr_name = f"Haus {direction_name} Helligkeit"
        self._attr_unique_id = f"smarthome_companion_sun_intensity_{direction_id}"
        self._attr_native_unit_of_measurement = "W/m²"
        self._attr_icon = "mdi:weather-sunny"

    @property
    def device_info(self) -> DeviceInfo:
        return DeviceInfo(
            identifiers={(DOMAIN, "hub")},
            name="SmartHome Companion",
            manufacturer="SmartHome Companion",
            model="Hub & Einstellungen",
        )

    @property
    def native_value(self):
        return round(self.sun_manager.intensities.get(self._direction_id, 0), 1)

    async def async_added_to_hass(self):
        self.async_on_remove(
            self.hass.bus.async_listen(
                "smarthome_companion_sun_updated", self._handle_update
            )
        )

    async def _handle_update(self, event):
        self.async_write_ha_state()


class _BlindBaseSensor(SensorEntity):
    def __init__(self, hass, store, blinds_manager, blind_id, sensor_type):
        self.hass = hass
        self.store = store
        self.blinds_manager = blinds_manager
        self._blind_id = blind_id
        self._sensor_type = sensor_type

    @property
    def available(self):
         return self._blind_id in self.store.get_blinds()

    @property
    def device_info(self) -> DeviceInfo:
        cover_name = self._cover_label(self._blind_id)
        return DeviceInfo(
            identifiers={(DOMAIN, self._blind_id)},
            name=cover_name,
            manufacturer="SmartHome Companion",
            model="Rollladen-Automat",
        )

    def _cover_label(self, entity_id):
        state = self.hass.states.get(entity_id)
        if state and state.attributes.get("friendly_name"):
            name = state.attributes["friendly_name"]
        else:
            name = entity_id.split(".")[-1].replace("_", " ").title()
        return name.replace("Eg", "EG").replace("Og", "OG").replace("Hacs", "HACS")

    async def async_added_to_hass(self):
        self.async_on_remove(
            self.hass.bus.async_listen(
                "smarthome_companion_blinds_updated", self._handle_update
            )
        )

    async def _handle_update(self, event):
        self.async_write_ha_state()


class BlindOpenTimeSensor(_BlindBaseSensor):
    def __init__(self, hass, store, blinds_manager, blind_id):
        super().__init__(hass, store, blinds_manager, blind_id, "open_time")
        self._attr_name = "Geplante Öffnungszeit"
        self._attr_unique_id = f"smarthome_companion_sensor_open_time_{blind_id}"
        self._attr_icon = "mdi:clock-start"

    @property
    def native_value(self):
        config = self.store.get_blinds().get(self._blind_id)
        if not config:
            return None
        now = dt_util.now()
        times_today = self.blinds_manager.calculate_times(self._blind_id, config, now.date())
        open_time = times_today.get("open_time")
        if open_time and open_time <= now:
            times_tomorrow = self.blinds_manager.calculate_times(self._blind_id, config, now.date() + timedelta(days=1))
            open_time = times_tomorrow.get("open_time")
        if open_time:
            return open_time.strftime("%H:%M")
        return None


class BlindCloseTimeSensor(_BlindBaseSensor):
    def __init__(self, hass, store, blinds_manager, blind_id):
        super().__init__(hass, store, blinds_manager, blind_id, "close_time")
        self._attr_name = "Geplante Schließzeit"
        self._attr_unique_id = f"smarthome_companion_sensor_close_time_{blind_id}"
        self._attr_icon = "mdi:clock-end"

    @property
    def native_value(self):
        config = self.store.get_blinds().get(self._blind_id)
        if not config:
            return None
        now = dt_util.now()
        times_today = self.blinds_manager.calculate_times(self._blind_id, config, now.date())
        close_time = times_today.get("close_time")
        if close_time and close_time <= now:
            times_tomorrow = self.blinds_manager.calculate_times(self._blind_id, config, now.date() + timedelta(days=1))
            close_time = times_tomorrow.get("close_time")
        if close_time:
            return close_time.strftime("%H:%M")
        return None


class BlindSunriseOpenTimeSensor(_BlindBaseSensor):
    def __init__(self, hass, store, blinds_manager, blind_id):
        super().__init__(hass, store, blinds_manager, blind_id, "sunrise_time")
        self._attr_name = "Sonnenaufgangs-Öffnungszeit"
        self._attr_unique_id = f"smarthome_companion_sensor_sunrise_open_time_{blind_id}"
        self._attr_icon = "mdi:weather-sunset-up"

    @property
    def native_value(self):
        config = self.store.get_blinds().get(self._blind_id)
        if not config:
            return None
        if not config.get("use_sunrise", False):
            return "Deaktiviert"
        now = dt_util.now()
        times_today = self.blinds_manager.calculate_times(self._blind_id, config, now.date())
        sunrise_time = times_today.get("sunrise_time")
        if sunrise_time and sunrise_time <= now:
            times_tomorrow = self.blinds_manager.calculate_times(self._blind_id, config, now.date() + timedelta(days=1))
            sunrise_time = times_tomorrow.get("sunrise_time")
        if sunrise_time:
            return sunrise_time.strftime("%H:%M")
        return "Deaktiviert"


class BlindSunsetCloseTimeSensor(_BlindBaseSensor):
    def __init__(self, hass, store, blinds_manager, blind_id):
        super().__init__(hass, store, blinds_manager, blind_id, "sunset_time")
        self._attr_name = "Sonnenuntergangs-Schließzeit"
        self._attr_unique_id = f"smarthome_companion_sensor_sunset_close_time_{blind_id}"
        self._attr_icon = "mdi:weather-sunset-down"

    @property
    def native_value(self):
        config = self.store.get_blinds().get(self._blind_id)
        if not config:
            return None
        if not config.get("use_sunset", False):
            return "Deaktiviert"
        now = dt_util.now()
        times_today = self.blinds_manager.calculate_times(self._blind_id, config, now.date())
        sunset_time = times_today.get("sunset_time")
        if sunset_time and sunset_time <= now:
            times_tomorrow = self.blinds_manager.calculate_times(self._blind_id, config, now.date() + timedelta(days=1))
            sunset_time = times_tomorrow.get("sunset_time")
        if sunset_time:
            return sunset_time.strftime("%H:%M")
        return "Deaktiviert"


class BlindNextActionSensor(_BlindBaseSensor):
    def __init__(self, hass, store, blinds_manager, blind_id):
        super().__init__(hass, store, blinds_manager, blind_id, "next_action")
        self._attr_name = "Nächste Aktion"
        self._attr_unique_id = f"smarthome_companion_sensor_next_action_{blind_id}"
        self._attr_icon = "mdi:clock-check-outline"

    @property
    def native_value(self):
        config = self.store.get_blinds().get(self._blind_id)
        if not config:
            return None
        
        now = dt_util.now()
        times_today = self.blinds_manager.calculate_times(self._blind_id, config, now.date())
        open_time = times_today.get("open_time")
        close_time = times_today.get("close_time")
        
        if not open_time or not close_time:
            return None
            
        next_open = open_time
        if next_open <= now:
            times_tomorrow = self.blinds_manager.calculate_times(self._blind_id, config, now.date() + timedelta(days=1))
            next_open = times_tomorrow.get("open_time")
            
        next_close = close_time
        if next_close <= now:
            times_tomorrow = self.blinds_manager.calculate_times(self._blind_id, config, now.date() + timedelta(days=1))
            next_close = times_tomorrow.get("close_time")
            
        if not next_open or not next_close:
            return None
            
        if next_open < next_close:
            return f"Öffnen um {next_open.strftime('%H:%M')}"
        else:
            return f"Schließen um {next_close.strftime('%H:%M')}"

    @property
    def extra_state_attributes(self):
        config = self.store.get_blinds().get(self._blind_id)
        if not config:
            return {}
        
        now = dt_util.now()
        times_today = self.blinds_manager.calculate_times(self._blind_id, config, now.date())
        open_time = times_today.get("open_time")
        close_time = times_today.get("close_time")
        
        if not open_time or not close_time:
            return {}
            
        next_open = open_time
        if next_open <= now:
            times_tomorrow = self.blinds_manager.calculate_times(self._blind_id, config, now.date() + timedelta(days=1))
            next_open = times_tomorrow.get("open_time")
            open_offset = times_tomorrow.get("open_offset", 0)
        else:
            open_offset = times_today.get("open_offset", 0)
            
        next_close = close_time
        if next_close <= now:
            times_tomorrow = self.blinds_manager.calculate_times(self._blind_id, config, now.date() + timedelta(days=1))
            next_close = times_tomorrow.get("close_time")
            close_offset = times_tomorrow.get("close_offset", 0)
        else:
            close_offset = times_today.get("close_offset", 0)
            
        if next_open < next_close:
            action = "Öffnen"
            next_dt = next_open
            offset = open_offset
        else:
            action = "Schließen"
            next_dt = next_close
            offset = close_offset
            
        return {
            "next_action": action,
            "next_time": next_dt.strftime("%H:%M"),
            "next_datetime": next_dt.isoformat(),
            "offset_minutes": offset,
        }
